wrdata<-read.csv('writingportfolio.csv', header=TRUE)
for (i in 1:13){wrdata[142,i+1]<-mean(wrdata[i+1][(1:141),])}
for (i in 1:13){wrdata[143,i+1]<-sd(wrdata[i+1][(1:141),])}
for (i in 1:141){for (j in 1:13){wrdata[j+1][i,]<-((wrdata[j+1][i,]-wrdata[j+1][142,])/wrdata[j+1][143,])}}
write.table(wrdata,"/Accounts/wangc/Desktop/CS324/wrdatafinal.txt",sep="\t")